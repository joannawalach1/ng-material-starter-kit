export interface MenuModel {
  readonly category: string;
}
